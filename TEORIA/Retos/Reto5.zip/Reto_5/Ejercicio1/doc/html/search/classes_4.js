var searchData=
[
  ['node_37',['node',['../classbintree_1_1node.html',1,'bintree']]]
];
