var searchData=
[
  ['level_5fiterator_36',['level_iterator',['../classbintree_1_1level__iterator.html',1,'bintree']]]
];
