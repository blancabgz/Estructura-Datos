var searchData=
[
  ['insert_5fleft_44',['insert_left',['../classbintree.html#a49d681962f17c3ef0b63ddd529d15e6a',1,'bintree::insert_left(const bintree&lt; T &gt;::node &amp;n, const T &amp;e)'],['../classbintree.html#a17611b995af1d5421197d155e75e683f',1,'bintree::insert_left(node n, bintree&lt; T &gt; &amp;rama)']]],
  ['insert_5fright_45',['insert_right',['../classbintree.html#a8f25464ce656370a6ab5d56ac56a3b5e',1,'bintree::insert_right(node n, const T &amp;e)'],['../classbintree.html#a01c798112c64624e3e90ed027bfd76e1',1,'bintree::insert_right(node n, bintree&lt; T &gt; &amp;rama)']]]
];
