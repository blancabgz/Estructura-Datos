var searchData=
[
  ['empty_43',['empty',['../classbintree.html#aefb9ea2b80770fec7cb1c0486740e25b',1,'bintree']]]
];
