var searchData=
[
  ['lexico_5fstack_0',['lexico_stack',['../utilidades_8h.html#a15428f7549a304139fba3316f5a65659',1,'utilidades.h']]]
];
