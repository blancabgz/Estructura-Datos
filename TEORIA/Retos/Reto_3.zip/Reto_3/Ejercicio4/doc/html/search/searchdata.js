var indexSectionsWithContent =
{
  0: "lu",
  1: "u",
  2: "l"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions"
};

var indexSectionLabels =
{
  0: "Todo",
  1: "Archivos",
  2: "Funciones"
};

