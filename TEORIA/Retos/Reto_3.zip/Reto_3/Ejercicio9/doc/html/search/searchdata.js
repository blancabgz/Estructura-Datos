var indexSectionsWithContent =
{
  0: "iru",
  1: "u",
  2: "ir"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions"
};

var indexSectionLabels =
{
  0: "Todo",
  1: "Archivos",
  2: "Funciones"
};

