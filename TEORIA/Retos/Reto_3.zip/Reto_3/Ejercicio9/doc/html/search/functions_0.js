var searchData=
[
  ['imprimir_5fpila_4',['imprimir_pila',['../utilidades_8h.html#a870ed98cbf03967a1dd913b8b437b19a',1,'utilidades.h']]]
];
