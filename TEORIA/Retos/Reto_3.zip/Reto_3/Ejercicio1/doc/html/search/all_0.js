var searchData=
[
  ['ppt_0',['ppt',['../utilidades_8h.html#a457e3ab59f85cf8a1b854ef2c5d8e20d',1,'utilidades.h']]]
];
